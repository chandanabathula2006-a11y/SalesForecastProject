!pip install pandas numpy matplotlib seaborn scikit-learn statsmodels

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

df = pd.read_csv('/content/Sample - Superstore.csv', encoding='latin1')

print(df.head())
print(df.info())
print(df.describe())

df.dropna(inplace=True)
df.drop_duplicates(inplace=True)

df['Order Date'] = pd.to_datetime(df['Order Date'])

df.set_index('Order Date', inplace=True)

plt.figure(figsize=(12,6))
plt.plot(df['Sales'])
plt.title('Sales Over Time')
plt.show()


df.sort_index(inplace=True)
train = df[:'2016']
test = df.loc['2017']

pip install prophet

from prophet import Prophet

data = df.reset_index()[['Order Date', 'Sales']]
data.columns = ['ds', 'y']

model = Prophet()
model.fit(data)

# Ensure the future dataframe is continuous daily across the entire historical range
# and for the additional 30 periods.
future = model.make_future_dataframe(periods=30, freq='D')

forecast = model.predict(future)

model.plot(forecast)
plt.show()

from sklearn.metrics import mean_absolute_error
import pandas as pd

# Calculate actual daily sales from the test set
# Assuming 'test' is a DataFrame with 'Sales' column and 'Order Date' as index
actual_daily = test['Sales'].resample('D').sum()

# Ensure forecast 'ds' column is datetime type for robust alignment
forecast['ds'] = pd.to_datetime(forecast['ds'])
forecast_indexed = forecast.set_index('ds')

# Filter the actual daily series to only include dates that are present in the forecast index
actual_aligned = actual_daily[actual_daily.index.isin(forecast_indexed.index)]

# Get predicted values for the aligned actual dates
# This will now only select keys that are present in forecast_indexed
predicted_aligned = forecast_indexed.loc[actual_aligned.index, 'yhat']

# Calculate Mean Absolute Error with aligned series
mae = mean_absolute_error(actual_aligned, predicted_aligned)
print(f"Mean Absolute Error (MAE): {mae}")